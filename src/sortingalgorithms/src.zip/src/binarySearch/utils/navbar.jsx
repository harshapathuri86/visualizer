import React from "react";

const NavBar = () => (
    <div className="bg-dark py-2 px-2">
        <span>
            <a>
                BINARY SEARCH
            </a>
        </span>
    </div>
);

export default NavBar;
